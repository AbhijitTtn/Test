package com.ecommerce.bootcampecommerce.controller;

import com.ecommerce.bootcampecommerce.dto.CustomerDTO;

import com.ecommerce.bootcampecommerce.repository.CustomerRepository;
import com.ecommerce.bootcampecommerce.repository.RoleRepository;
import com.ecommerce.bootcampecommerce.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

import java.util.List;


@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    CustomerService customerService;

    @Autowired
    CustomerRepository customerRepository;

    @Autowired
    RoleRepository roleRepository;

    @GetMapping("/customer")
    public List<CustomerDTO> findAllSellerData(){
        return customerService.getCustomers();
    }

    @PostMapping("/customer")
    public ResponseEntity<Object> saveCustomer(@Valid @RequestBody CustomerDTO customerDTO){
        //return  new ResponseEntity<>(customerService.saveCustomer(customerDTO), HttpStatus.OK);
        CustomerDTO customerDTO1 = customerService.saveCustomer(customerDTO);
        if(customerDTO1 == null){
            return new ResponseEntity<>("Password doesn't matched. " +
                    "\nPlease Check the confirm password and try again", HttpStatus.INTERNAL_SERVER_ERROR);
        } else {
            return new ResponseEntity<>("Created", HttpStatus.CREATED);
        }
    }
}
