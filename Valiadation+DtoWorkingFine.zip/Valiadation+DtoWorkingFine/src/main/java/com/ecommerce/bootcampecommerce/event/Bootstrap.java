package com.ecommerce.bootcampecommerce.event;

import com.ecommerce.bootcampecommerce.entity.Role;
import com.ecommerce.bootcampecommerce.entity.User;
import com.ecommerce.bootcampecommerce.repository.RoleRepository;
import com.ecommerce.bootcampecommerce.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

@Component
public class Bootstrap implements ApplicationRunner {

    @Autowired
    UserRepository userRepository;

    @Autowired
    RoleRepository roleRepo;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        if((Objects.isNull(roleRepo.findByAuthority("Admin")))
                || (Objects.isNull(roleRepo.findByAuthority("Customer")))
        ||(Objects.isNull(roleRepo.findByAuthority("Seller"))))
        {
            roleRepo.deleteAll();

            Role role1 = new Role();
            Role role2=new Role();
            Role role3=new Role();

            role1.setAuthority("Admin");roleRepo.save(role1);
            role2.setAuthority("Customer");roleRepo.save(role2);
            role3.setAuthority("Seller");roleRepo.save(role3);
        }

        if(Objects.isNull(userRepository.findByEmail("admin@gmail.com"))) {

            Role role=roleRepo.findByAuthority("Admin");

            Set<Role> roles = new HashSet<>();
            roles.add(role);

            User user = new User();
            user.setEmail("admin@gmail.com");
            user.setPassword("Password@1");
            user.setFirstName("Peter");
            user.setLastName("Parker");
            user.setRoles(roles);

            userRepository.save(user);
        }
    }
}