package com.ecommerce.bootcampecommerce.service;

import com.ecommerce.bootcampecommerce.dto.CustomerDTO;


import java.util.List;



public interface CustomerService {
    public List<CustomerDTO> getCustomers();
    public CustomerDTO saveCustomer(CustomerDTO customerDTO);

}
