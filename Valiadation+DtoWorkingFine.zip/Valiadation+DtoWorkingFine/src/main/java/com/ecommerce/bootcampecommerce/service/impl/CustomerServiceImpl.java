package com.ecommerce.bootcampecommerce.service.impl;

import com.ecommerce.bootcampecommerce.dto.CustomerDTO;
import com.ecommerce.bootcampecommerce.entity.Customer;
import com.ecommerce.bootcampecommerce.entity.Role;
import com.ecommerce.bootcampecommerce.entity.User;
import com.ecommerce.bootcampecommerce.repository.CustomerRepository;
import com.ecommerce.bootcampecommerce.repository.RoleRepository;
import com.ecommerce.bootcampecommerce.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    CustomerRepository customerRepository;
    @Autowired
    RoleRepository roleRepository;

    @Override
    public List<CustomerDTO> getCustomers() {
        return customerRepository.findAll().stream()
                .map(o -> new CustomerDTO(o.getUser().getEmail(), o.getUser().getFirstName()
                        , o.getUser().getLastName(), o.getUser().getMiddleName(),
                        o.getUser().getPassword(), o.getUser().getConfirmPassword()
                        ,o.getUser().getRoles(), o.getUser().getPasswordUpdateDate(),
                        o.getContactNumber())).collect(Collectors.toList());
    }

    @Override
    public CustomerDTO saveCustomer(CustomerDTO customerDTO) {
        User user = new User();
        user.setEmail(customerDTO.getEmail());
        user.setFirstName(customerDTO.getFirstName());
        user.setPassword(customerDTO.getPassword());
        user.setMiddleName(customerDTO.getMiddleName());
        user.setConfirmPassword(customerDTO.getConfirmPassword());
        user.setPasswordUpdateDate(new Date());
        user.setLastName(customerDTO.getLastName());
        Customer customer = new Customer();
        customer.setUser(user);
        customer.setContactNumber(customerDTO.getContactNumber());
        Role role = roleRepository.findByAuthority("Customer");
        Set<Role> roleList = new HashSet<>();
        roleList.add(role);
        user.setRoles(roleList);
        String password = user.getPassword();
        String confirmPassword = user.getConfirmPassword();
        if (password.equals(confirmPassword)) {
            customerRepository.save(customer);
            return customerDTO;
        } else {
            return null;
        }
    }
}
