package com.ecommerce.bootcampecommerce;

import com.ecommerce.bootcampecommerce.entity.*;
import com.ecommerce.bootcampecommerce.repository.CustomerRepository;
import com.ecommerce.bootcampecommerce.repository.RoleRepository;
import com.ecommerce.bootcampecommerce.repository.SellerRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.HashSet;
import java.util.Set;

@SpringBootTest
class BootcampecommerceApplicationTests {

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	SellerRepository sellerRepository;

	@Autowired
	RoleRepository roleRepository;

	@Test
	void contextLoads() {
	}

	@Test
	void createCustomer(){

		Role role=roleRepository.findByAuthority("customer");

		Set<Role> roles = new HashSet<>();
		roles.add(role);

		User user = new User();
		user.setFirstName("Peter");
		user.setLastName("Singh");
		user.setEmail("test@gmail.com");
		user.setPassword("pass@1234");
		user.setRoles(roles);

		Address address1 = new Address();
		address1.setCity("London");
		address1.setState("los vegas");
		address1.setCountry("Us");
		address1.setZipcode("842001");
		address1.setAddressline("E street");
		address1.setLabel("home");

		Address address2 = new Address();
		address2.setCity("delhi");
		address2.setState("delhi 6");
		address2.setCountry("india");
		address2.setZipcode("842001");
		address2.setAddressline("E street");
		address2.setLabel("home");

		Set<Address> addressSet = new HashSet<>();
		addressSet.add(address1);
		addressSet.add(address2);

		Customer customer = new Customer();
		customer.setContactNumber("8090151253");
		user.setAddresses(addressSet);
		customer.setUser(user);

		customerRepository.save(customer);
	}




}
